# RebarOptima — Codebase Audit for Google Stitch Design

**Audit date:** 2026-10-29  
**Source of truth:** Repository source (not marketing assumptions)  
**Scope:** Read-only analysis of `frontend/` and `backend/`. No application source was modified for this package.

---

## 1. Verified architecture

### Product

**RebarOptima** is a multi-tenant construction SaaS focused on rebar (steel) optimization, BBS, casting, site inventory, drawings, petty cash, CPM/task management, and real-estate CRM. It is used by builders, engineers, contractors, PMs, supervisors, accountants, and sales roles within a **company (organization)** that owns multiple **construction projects**.

### Runtime stack

| Layer | Verified technology |
|-------|---------------------|
| Monorepo | npm workspaces: `frontend`, `backend` (`package.json`) |
| Frontend | Vite 8 + React 19 + Redux Toolkit |
| Routing | **No React Router.** Redux `routing.view` + `history.pushState` (`App.jsx`, `routingSlice.js`) |
| Backend (live) | **Express** in `backend/src/main.ts` (not NestJS at runtime) |
| Database | MongoDB (native driver in Express paths); Nest/Mongoose schemas exist as parallel scaffolding |
| Icons | `lucide-react` |
| Maps | Leaflet (geofence / project location) |
| CAD / drawings | Vue 3 + Element Plus island + `@mlightcad/*` + Three.js |
| PDF | `html2pdf.js`, `pdfjs-dist`, `react-to-print` |

### NestJS note

`backend/src/app.module.ts` and Nest modules exist, but the live entrypoint creates `express()` and mounts routers. Nest controllers are **not** the current UI API surface. Design against Express routes under `/api/*`.

### Mobile app

**No React Native / Expo / native mobile app exists inside Rebar-Optima.**  
Mobile deliverables in this package are **product design** for a companion field/ops experience based on verified web functionality. Do not claim mobile code already ships.

Responsive web: SideNavbar becomes a drawer at ≤900px CSS.

---

## 2. Modules (verified)

### Workspace modules (sidebar)

| Nav label | View id | Module permission key | Page |
|-----------|---------|----------------------|------|
| Overview | `overview` | *(always shown)* | `OverviewPage` |
| Projects | `projects` | `projects` | `ProjectsPage` |
| Inventory (Steel group) | `inventory` | `inventory` | `InventoryPage` |
| Ledger & Procurement | `ledger` | `ledger` | `LedgerPage` |
| Run Optimizer | `inputs` (+ `results`) | `optimizer` | `NewBatchPage`, `ResultsPage` |
| Batch History | `history` | `history` | `BatchHistoryPage` |
| BBS | `bbs` (+ `bbs-*`) | `bbs`* | `BBSPage` + siblings |
| Casting Management | `casting` | `casting` | `CastingPage` |
| Site Inventory | `general-inventory` | `generalInventory` | `GeneralInventoryPage` |
| Real Estate CRM | `crm` | `crm` | `CrmPage` |
| Projects & Tasks | `project-management` | `projectManagement` | `ProjectManagementPage` |
| Drawing & Files | `drawings` | `drawings` | `DrawingsPage` |
| Petty Cash | `petty-cash` | `pettyCash` | `PettyCashPage` |
| Settings | `settings` | `settings` | `SettingsPage` |
| User Management | `users` | `users` | `UsersPage` |
| Roles & Permissions | `roles` | `roles` | `RolesPage` |
| Activity Logs | `activity-logs` | `activityLogs` | `ActivityLogsPage` |
| Profile | `profile` | *(account)* | `ProfilePage` |

\* `bbs` is used in the frontend nav; it is **not** listed in backend `PLATFORM_MODULES` (gating ambiguity — see unresolved decisions).

### Auth / platform surfaces

| Surface | View / path | Notes |
|---------|-------------|--------|
| Sign in | `signin` → `/login` | Email/password |
| Sign up | `signup` → `/register` | Creates company + Admin + trial |
| Subscribe gate | `subscribe` | Suspended company or expired subscription |
| No project | `no-project` | Zero projects or invalid selection |
| Developer login | `superadmin-login` → `/developer-login` | Hidden entry (logo / shortcut) |
| Developer console | `superadmin` → `/developer` | Companies, packages, subscriptions, audit |

### Backend API mounts (Express)

| Prefix | Domain |
|--------|--------|
| `/api/auth/*`, `/api/permissions/effective`, `/api/roles`, `/api/users`, `/api/activity-logs` | Auth & admin |
| `/api/projects` (+ blocks, geofences, partners) | Canonical projects |
| `/api/inventory`, `/api/batches` | Steel inventory & cut optimizer |
| `/api/bbs` | Bar bending schedule hierarchy |
| `/api/casting` | Casting events, recipes, quality |
| `/api/general-inventory` | Site stores & materials |
| `/api/crm` | Real-estate CRM |
| `/api/drawings` | Drawing register & transmittals |
| `/api/petty-cash` | Petty cash |
| `/api/pm` | CPM / tasks / DPR / quality |
| `/api/developer/*` | Platform superadmin |
| `/api/public/packages` | Subscription packages |

---

## 3. Routes / views (complete map)

| Path | View id | Screen family |
|------|---------|---------------|
| `/login` | `signin` | Auth |
| `/register` | `signup` | Auth |
| `/` | `overview` | Dashboard |
| `/projects` | `projects` | Company projects + blocks |
| `/inventory` | `inventory` | Steel inventory |
| `/ledger` | `ledger` | Ledger & procurement |
| `/inputs` | `inputs` | Optimizer input |
| `/results` | `results` | Optimizer results |
| `/history` | `history` | Batch history |
| `/bbs` | `bbs` / `bbs-projects` | BBS |
| `/bbs/dashboard` | `bbs-dashboard` | BBS dashboard |
| `/bbs/wizard` | `bbs-wizard` | BBS wizard |
| `/bbs/shapes` | `bbs-shapes` | Shape library |
| `/bbs/reports` | `bbs-reports` | BBS reports |
| `/casting` | `casting` | Casting |
| `/general-inventory` | `general-inventory` | Site inventory |
| `/crm` | `crm` | CRM |
| `/project-management` | `project-management` | PM / CPM |
| `/drawings` | `drawings` | Drawings |
| `/petty-cash` | `petty-cash` | Petty cash |
| `/settings` | `settings` | Settings |
| `/users` | `users` | Users |
| `/roles` | `roles` | Roles |
| `/activity-logs` | `activity-logs` | Audit |
| `/profile` | `profile` | Profile |
| `/developer-login` | `superadmin-login` | Dev auth |
| `/developer` | `superadmin` | Dev console |
| *(view)* `subscribe` | `subscribe` | Billing gate |
| *(view)* `no-project` | `no-project` | Empty project state |

---

## 4. Roles and permissions

### System roles (seeded)

Admin, Project Partner Admin, Project Manager, Senior Site Engineer, Junior Site Engineer, Site Supervisor, Accountant, Sales Executive, Purchase Manager, Store Keeper — each with module/feature maps and `dataScope`: `organization` | `project`.

### Legacy user.role strings (schema)

`SUPPORT | OWNER | ADMIN | ENGINEER | OPERATOR | VIEWER | PROJECT_PARTNER_ADMIN`

### Frontend nav gating

1. Admin / Owner / developer → all modules  
2. `PROJECT_PARTNER_ADMIN` → hardcoded `PARTNER_ALLOWED_MODULES` (Overview, Projects, Steel cluster, BBS, Casting, Drawings) — **excludes** Site Inventory, CRM, PM, Petty Cash, Users, Roles, Settings, Activity Logs even if backend grants differ  
3. Else → `permissions[moduleKey] !== false`

### Data scope

- Organization-scoped roles see company projects.  
- Project-scoped / partner admins use `assignedProjects` + `X-Project-Id`.  
- API is authoritative; UI hiding is not security.

### Subscription / company status

- Company: `active | inactive | suspended`  
- Subscription: `trial | active | expired` (signup = FREE trial ~7 days)  
- Suspended or expired → Subscribe page; module access denied via `canAccess`

---

## 5. Project and block relationships

### Canonical project

Collection `projects`: `companyId`, `name`, `address`, `pincode`, `location{lat,lng}`, `projectType` (`Residential | Mixed-use | Commercial | Villa | Other`), `status` (`active | inactive`), `geofences[]`, `assignedPartnerAdminIds`, `blockCount`.

### Canonical blocks

Collection `project_blocks`: per-project towers/wings; unique active name; max **200** per project; soft-archive; create with project or via `/api/projects/:id/blocks`.

### Global project selector

- Lives in SideNavbar (`ProjectSelector`)  
- Hint in `localStorage` (`rebar_active_project_id`); validated via `GET /api/projects/:id`  
- Sets header `X-Project-Id`  
- `projectEpoch` invalidates module caches on switch  
- Most operational modules are project-scoped

### Module-specific project catalogs (migration in progress)

Historical: `bbs_projects`, `casting_projects`, `crm_projects`, `doc_projects`, `gi_projects` bridged via `module-project-adapter` / `orgProjectId`. Casting create-project API redirects to global projects.

### Dual project UX (verified inconsistency)

`ProjectManagementPage` keeps a **local** project `<select>` from `pmApi.getProjects()`, which may diverge from the shell ProjectSelector. CRM also tracks `selectedProjectId` in page state while respecting `projectEpoch`. Design must document both patterns until product unifies them.

### Attendance / GPS check-in

**Out of scope in product matrix.** Geofences are stored on projects (circle/polygon) for configuration; **no attendance/check-in APIs** exist. Mobile design must not invent live GPS attendance unless marked as future/optional concept separate from verified product.

---

## 6. Existing UI patterns

- Dense HTML tables + tabbed modules  
- Page-local modals; shared primitives emerging under `components/ui/` (`PageHeader`, `Button`, `EmptyState`, `StatusBadge`, `DataToolbar`, `AppModal`)  
- Default theme: **dark** + color theme **slate-emerald** (also steel-blue, classic-purple)  
- Font: **Inter**  
- Custom SVG KPIs on Overview; PM Gantt custom; CRM kanban/chessboard unit views  
- Breadcrumbs: Home / Org / Project trail (some view titles missing)

---

## 7. Known UX issues (from code + `docs/UX_AUDIT_REBAROPTIMA.md`)

1. Dense tables; inconsistent modals and empty states  
2. Project switch stale-data risk if a page ignores `projectEpoch`  
3. Partner Admin frontend allowlist vs backend permissions mismatch  
4. PM / CRM local project selection vs global selector  
5. BBS dual surfaces (`BBSPage` vs `bbs-*` routes) — canonical UX unclear  
6. Breadcrumbs missing titles for `project-management`, `petty-cash`  
7. Drawings Vue CAD island = dual visual language  
8. `PLATFORM_MODULES` lags some frontend modules (e.g. BBS key)  
9. Attendance listed out_of_scope — do not invent field check-in as current product  
10. DrawingsPage has signs of incomplete/mid-merge load logic (verify before assuming all drawing tabs work)

---

## 8. Unresolved questions

See `17-unresolved-design-decisions.md` for the full list. Highest impact:

- Unify global vs module project selectors?  
- Which BBS surface is canonical?  
- Should Partner Admin nav match backend grants?  
- Is a native mobile app planned, or responsive web only?  
- Are geofences for future attendance or only project metadata?

---

## 9. Design implications (facts → Stitch)

| Verified fact | Design implication |
|---------------|--------------------|
| Company → many projects → many blocks | Always show active project; block UIs filtered by project |
| Steel vs Site Inventory | Distinct labels and icons |
| Optimizer is a multi-step flow | Dedicated screens: inputs → results → history |
| No mobile codebase | Mobile prompts = new companion UX, not “existing app redesign” |
| Role × module matrix | Design permission-denied and hidden-nav states |
| Data-heavy construction workflows | Prefer Linear/Stripe clarity with industrial density, not consumer marketing layouts |

---

## Legend

- **Verified:** Confirmed in source  
- **Inferred:** Reasonable from structure; not over-claimed in prompts  
- **Recommendation:** Design guidance, not existing behavior
