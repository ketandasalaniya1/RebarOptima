# RebarOptima — Complete Screen Inventory

**Source:** Frontend views, page tabs, App-level modals, and backend-backed workflows.  
**Counts (verified):** ~28 primary view IDs; **90+** distinct desktop screens/states when counting tabs, wizards, and major modals; mobile = designed companion set (no native app in repo).

Legend for **Implementation status:** `shipped` | `partial` | `broken/uncertain` | `design-only (mobile)`.

---

## A. Authentication & platform gate

### A1. Sign In
| Field | Value |
|-------|--------|
| Module | Auth |
| Route | `/login` (`signin`) |
| Purpose | Company user login |
| Roles | All unauthenticated users |
| Nav | Public |
| Actions | Sign in, go to Sign up, remember email, hidden developer entry |
| Fields | Email, password |
| States | Loading, invalid credentials, session expired redirect |
| Project/block | None |
| Status | shipped |
| UX notes | Dark industrial auth; developer easter egg |

### A2. Sign Up
| Field | Value |
|-------|--------|
| Module | Auth |
| Route | `/register` (`signup`) |
| Purpose | Create company + Admin + trial subscription |
| Actions | Register, navigate to Sign in |
| Fields | Company name, user name, email, password, location fields as implemented |
| Status | shipped |

### A3. Subscribe / Billing Gate
| Field | Value |
|-------|--------|
| Module | Subscription |
| View | `subscribe` |
| Purpose | Block workspace when company suspended or subscription expired; show packages |
| Roles | Authenticated restricted users |
| Actions | View packages, contact/upgrade (per UI) |
| Status | shipped |
| UX notes | Must feel like a hard gate, not a soft banner |

### A4. No Project
| Field | Value |
|-------|--------|
| Module | Projects |
| View | `no-project` |
| Purpose | Empty state when company has zero projects or none selectable |
| Actions | Create project (Admin/Owner), logout |
| Related | ProjectFormModal |
| Status | shipped |

### A5. Developer Login
| Field | Value |
|-------|--------|
| Route | `/developer-login` |
| Purpose | Platform developer authentication |
| Status | shipped |

### A6. Developer Console
| Field | Value |
|-------|--------|
| Route | `/developer` |
| Tabs | Companies, Packages, Subscriptions, Audit |
| Actions | CRUD companies/status, manage packages/subs, view audit |
| Status | shipped |

### A7. Project bootstrap loading
| Field | Value |
|-------|--------|
| Purpose | “Loading your projects…” while permissions + project list validate |
| Status | shipped |

---

## B. Application shell (all workspace screens)

| Screen | Purpose |
|--------|---------|
| SideNavbar | Module nav, RBAC filter, Steel accordion, theme toggle, profile, logout |
| ProjectSelector | Active project switch + create (privileged) |
| Breadcrumbs | Context trail |
| ProjectFormModal | Create (details→blocks→review) / edit project |
| GeofenceConfigModal | Leaflet circle/polygon geofences |
| AssignPartnerModal | Assign partner admins |
| Permission denied / hidden nav | Module absent from nav when RBAC false |

---

## C. Overview

| Screen | Route | Purpose | Actions | Data |
|--------|-------|---------|---------|------|
| C1 Overview dashboard | `/` | Project-scoped KPIs and shortcuts | Navigate to inventory/ledger/history etc. | Stock, scrap, batch stats (as implemented) |

Roles: all with workspace access. Project: required. Status: shipped. UX: KPIs should be actionable (audit A4).

---

## D. Projects & blocks

| Screen | Route / entry | Purpose | Roles | Actions | Fields / UI |
|--------|---------------|---------|-------|---------|-------------|
| D1 Projects list | `/projects` | Company project catalog | `projects.view` | Search/filter, select, create, edit, status, geofence, partners | Cards/list: name, type, status, address, blockCount |
| D2 Project blocks panel | ProjectsPage selection | Manage towers/wings | Admin/Owner/developer edit | Add, rename, archive | Block name, order, status |
| D3 Create project wizard | Modal | Create project + blocks | create permission | Multi-step | name, address, pincode, lat/lng, type, block count/names |
| D4 Edit project | Modal | Update metadata | edit | Save | Same without blocks payload |
| D5 Geofence config | Modal | Site boundaries | `projects.geofence` | Draw circle/polygon, save | Map |
| D6 Assign partners | Modal | Partner admin ACL | Admin | Assign/unassign | User list |

Project dependency: blocks always under one project. Status: shipped.

---

## E. Steel cluster

### E1 Inventory (`/inventory`) — tabs
| Tab | Purpose | Actions |
|-----|---------|---------|
| list | Stock items | View, filter, edit/delete if permitted |
| inward | Add stock | Inward voucher form |
| batchscrap | Batch scrap records | View scrap from cuts |
| scrapsales | Scrap sales | Create/edit scrap sales |

Fields: diameter, length (mm), quantity, cost/kg, bar type, brand, vendor, remnant flag, weight.

### E2 Ledger (`/ledger`) — tabs
ledger | inward-cost | orders | requests — procurement and cost views.

### E3 Run Optimizer (`/inputs`)
Form: stock selection, required parts, kerf/trim; run optimize → navigate to results.

### E4 Results (`/results`)
Layouts, utilization, scrap summary; save batch → history; back to inputs.

### E5 Batch History (`/history`)
Table of batches; edit (reload inputs), delete, export as permitted.

Project: required for all. Status: shipped.

---

## F. BBS

| Screen | Route | Purpose |
|--------|-------|---------|
| F1 BBS main | `/bbs` (`bbs`) | Hierarchy: project/block/level/member; tabs projects/shapes/cad |
| F2 BBS projects alt | `bbs-projects` | Alternate projects surface |
| F3 BBS dashboard | `/bbs/dashboard` | KPIs / status |
| F4 BBS wizard | `/bbs/wizard` | Member/rebar entry wizard |
| F5 Shapes library | `/bbs/shapes` | Shape templates / versions |
| F6 Reports | `/bbs/reports` | Printable reports |
| F7 Shape detail / version modals | Modals | Shape params, new version, calc trace |

**Ambiguity:** F1 vs F2–F6 dual entry — treat F1 as primary workspace; others as related workflows in design.

Hierarchy: Project → Block → Level → Member → Shapes/instances. Project: required. Status: shipped (partial CAD complexity).

---

## G. Casting (`/casting`)

Tabs: structural | events | timeline | recipes | curing | cubes | tracksheet  

Major modals/views: hierarchy manager, create member, create event, recipe create/detail, segment recipe assign, consumption approval, actual consumption, project stock register, curing, cube testing, track sheet, timeline.

Company-scoped: recipes library. Project-scoped: members/events/stock/quality. Status: shipped.

---

## H. Site Inventory (`/general-inventory`)

Tabs: overview | materials | inward | outward | returns | transfers | audit | reports  

Entities: stores, materials, stock balances, transactions, verifications, adjustments, incidents. Project: required. Status: shipped.

---

## I. CRM (`/crm`)

Tabs: dashboard | customers | pipeline | inventory (units) | visits-tasks | bookings | payments | reports | settings  

UI patterns: KPI cards, customer table, kanban pipeline, unit chessboard/availability, visit/task lists, booking/payment tables.  

Customers/settings: company-scoped; units/leads/bookings: project-linked. Local project select + global epoch. Status: shipped.

---

## J. Project Management / CPM (`/project-management`)

Tabs/views: overview | projects | tasks | gantt | manpower | calendar | dpr | quality (+ cost productivity components)  

Modals: delay, reschedule. **Local PM project select** (may diverge from shell). Status: shipped.

---

## K. Drawings (`/drawings`)

Subviews: dashboard, internal projects, drawing register, revision history, discipline library, transmittals, activity, module settings/permissions, PDF/CAD viewers.  

Status: shipped with **uncertain** load path (mid-merge risk). Dual React/Vue chrome.

---

## L. Petty Cash (`/petty-cash`)

Ledger of credits/debits; filters; photo receipts; site/person/category settings modals. Project/site oriented. Status: shipped.

---

## M. Administration

| Screen | Route | Tabs / UI | Purpose |
|--------|-------|-----------|---------|
| Settings | `/settings` | Theme mode/color, kerf/trim defaults, storage quota, scrap rules | Company/client prefs |
| Users | `/users` | Table + forms | CRUD, role, project assignment, status |
| Roles | `/roles` | Role editor | Module/feature toggles, dataScope |
| Activity Logs | `/activity-logs` | Filters, pagination, export | Audit |
| Profile | `/profile` | identity / preferences / security / activity | Account self-service |

---

## N. Mobile classification (design-only — no RN app)

| Feature | Classification | Reasoning |
|---------|----------------|-----------|
| Sign in / profile | Full mobile | Daily entry |
| Overview home | Simplified | Key KPIs + shortcuts |
| Project list / switch | Full | Context critical |
| Project details / blocks | Simplified | View + limited edit for admins |
| Steel inventory view | Simplified / read-heavy | Tables → cards |
| Stock inward | Simplified | Field receive |
| Optimizer run | Desktop-only (justified) | Complex multi-stock layout UX |
| Optimizer results view | Read-only mobile | Review saved batch summaries |
| BBS hierarchy browse | Simplified | Field reference |
| BBS CAD editor | Desktop-only | Precision CAD |
| Casting events / curing | Simplified | Site updates |
| Site inventory inward/outward | Full | Storekeeper field ops |
| CRM visits/tasks | Full | Sales field |
| CRM pipeline/settings | Simplified / desktop-leaning | Dense config |
| PM tasks / DPR | Full | Site supervisors |
| PM Gantt / baseline | Desktop-only / read-only | Dense schedule |
| Drawings view / mark | Simplified | PDF view on phone; CAD desktop |
| Petty cash + photo | Full | Site spend |
| Users/Roles/Packages | Desktop-only | Admin density |
| Geofence draw | Desktop-leaning | Map editing hard on phone; view OK |
| Attendance check-in | **Not in product** | Do not design as shipped; optional future note only |
| Developer console | Desktop-only | Platform ops |

---

## O. Shared states (every screen)

Loading, empty, error, success toast, confirmation (destructive), permission denied, offline (mobile recommendation), project-required gate, subscription gate.
