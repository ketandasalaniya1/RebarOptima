# Screen Coverage Matrix

Track design deliverables vs verified product surfaces.  
Statuses: `done` | `prompt-ready` | `partial` | `n/a` | `blocked` | `todo-review`

| ID | Module | Screen / feature | Route / ref | Desktop | Mobile | Design system | Prompt file | Review | Outstanding |
|----|--------|------------------|-------------|---------|--------|---------------|-------------|--------|-------------|
| A1 | Auth | Sign In | `/login` | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| A2 | Auth | Sign Up | `/register` | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| A3 | Billing | Subscribe gate | `subscribe` | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| A4 | Projects | No project | `no-project` | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| A5 | Platform | Developer login | `/developer-login` | prompt-ready | n/a | yes | 06 | todo-review | Mobile intentionally excluded |
| A6 | Platform | Developer console | `/developer` | prompt-ready | n/a | yes | 06 | todo-review | Desktop-only |
| A7 | Shell | Bootstrap loading | App | prompt-ready | prompt-ready | yes | 05, 08 | todo-review | — |
| B1 | Shell | Sidebar + top context | App | prompt-ready | n/a (drawer/bottom nav) | yes | 05 | todo-review | — |
| B2 | Shell | Project selector | SideNavbar | prompt-ready | prompt-ready | yes | 05, 08 | todo-review | Unify dual PM/CRM select |
| B3 | Shell | Breadcrumbs | Breadcrumbs | prompt-ready | simplified | yes | 05 | todo-review | Fix missing titles in impl later |
| B4 | Shell | Project form modal | ProjectFormModal | prompt-ready | simplified sheet | yes | 06 | todo-review | — |
| B5 | Shell | Geofence modal | GeofenceConfigModal | prompt-ready | view-only | yes | 06 | todo-review | Edit map desktop-first |
| B6 | Shell | Assign partner | AssignPartnerModal | prompt-ready | n/a | yes | 06 | todo-review | Desktop admin |
| C1 | Overview | Dashboard | `/` | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| D1 | Projects | List | `/projects` | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| D2 | Projects | Blocks panel | ProjectsPage | prompt-ready | prompt-ready | yes | 06, 09 | todo-review | — |
| E1 | Steel | Inventory tabs | `/inventory` | prompt-ready | simplified | yes | 06b, 09 | todo-review | — |
| E2 | Steel | Ledger tabs | `/ledger` | prompt-ready | read-only | yes | 06b, 09 | todo-review | — |
| E3 | Steel | Optimizer inputs | `/inputs` | prompt-ready | n/a | yes | 06b | todo-review | Desktop-only justified |
| E4 | Steel | Optimizer results | `/results` | prompt-ready | read-only | yes | 06b, 09 | todo-review | — |
| E5 | Steel | Batch history | `/history` | prompt-ready | simplified | yes | 06b, 09 | todo-review | — |
| F1 | BBS | Main workspace | `/bbs` | prompt-ready | simplified | yes | 06b, 09 | todo-review | Canonical surface decision |
| F3 | BBS | Dashboard | `/bbs/dashboard` | prompt-ready | simplified | yes | 06b, 09 | todo-review | — |
| F4 | BBS | Wizard | `/bbs/wizard` | prompt-ready | simplified | yes | 06b, 09 | todo-review | — |
| F5 | BBS | Shapes | `/bbs/shapes` | prompt-ready | read-only | yes | 06b, 09 | todo-review | CAD edit desktop |
| F6 | BBS | Reports | `/bbs/reports` | prompt-ready | read-only | yes | 06b, 09 | todo-review | — |
| G1 | Casting | All tabs | `/casting` | prompt-ready | simplified | yes | 06b, 09 | todo-review | Many modals |
| H1 | Site Inv | All tabs | `/general-inventory` | prompt-ready | full ops subset | yes | 06c, 09 | todo-review | — |
| I1 | CRM | All tabs | `/crm` | prompt-ready | field subset | yes | 06c, 09 | todo-review | Local project select |
| J1 | PM | All views | `/project-management` | prompt-ready | field subset | yes | 06c, 09 | todo-review | Local project select |
| K1 | Drawings | Register + viewers | `/drawings` | prompt-ready | PDF view | yes | 06d, 09 | todo-review | Impl uncertainty |
| L1 | Petty Cash | Ledger + settings | `/petty-cash` | prompt-ready | full | yes | 06d, 09 | todo-review | — |
| M1 | Admin | Settings | `/settings` | prompt-ready | theme prefs only | yes | 06d, 09 | todo-review | — |
| M2 | Admin | Users | `/users` | prompt-ready | n/a | yes | 06d | todo-review | Desktop-only |
| M3 | Admin | Roles | `/roles` | prompt-ready | n/a | yes | 06d | todo-review | Desktop-only |
| M4 | Admin | Activity logs | `/activity-logs` | prompt-ready | n/a | yes | 06d | todo-review | Desktop-only |
| M5 | Account | Profile | `/profile` | prompt-ready | prompt-ready | yes | 06d, 09 | todo-review | — |
| X1 | Future | Attendance GPS | — | n/a | blocked | — | 17 | — | Not in product; do not generate as shipped |
| X2 | Consistency | Cross-screen pass | all | prompt-ready | prompt-ready | yes | 11 | todo-review | After generation |
| X3 | QA | Desktop UX audit | all | prompt-ready | — | yes | 12 | todo-review | — |
| X4 | QA | Mobile UX audit | all | — | prompt-ready | yes | 13 | todo-review | — |
| X5 | QA | Completeness | all | prompt-ready | prompt-ready | yes | 14 | todo-review | — |
| X6 | Responsive | Breakpoints | all | prompt-ready | prompt-ready | yes | 10 | todo-review | — |

## Coverage summary

| Metric | Count |
|--------|-------|
| Primary view IDs in App | 28 |
| Desktop screen rows in matrix | 40+ (tabs expanded in module prompts) |
| Mobile full/simplified rows | ~28 applicable |
| Desktop-only justified | ~8 |
| Explicitly out of scope | Attendance |
| Prompt packages | 04–14 + splits 06b–06d |

Update the **Review** column to `done` after each Stitch generation + human pass.
