# 04 — Desktop Design System Prompt (Google Stitch)

> **How to use:** Copy everything inside the `PROMPT` fence below and paste into Google Stitch as the first generation for **RebarOptima Desktop Foundations**. Do not include this instruction header.

```PROMPT
Design a complete desktop SaaS design system for RebarOptima — a professional construction-management product for builders, architects, civil engineers, contractors, project managers, supervisors, storekeepers, accountants, and sales teams in India-focused construction companies.

PRODUCT CONTEXT (do not invent unrelated modules):
RebarOptima is a multi-tenant web app. One company has many construction projects. Each project can have many blocks/towers. Most operational data is filtered by the active project. Core domains already exist: Overview, Projects & Blocks, Steel Inventory, Ledger & Procurement, Rebar Cut Optimizer, Batch History, BBS (Bar Bending Schedule), Casting Management, Site Inventory, Real Estate CRM, Projects & Tasks (CPM), Drawings & Files, Petty Cash, Users, Roles, Settings, Activity Logs, Profile, Subscription gate, and a separate Developer console.

VISUAL DIRECTION:
- Premium industrial enterprise SaaS — clarity of Linear + trust of Stripe billing/admin, applied to construction operations.
- Clean, dense, highly readable. Practical over decorative. No playful illustrations, no emoji, no purple-glow consumer AI aesthetic.
- Strong hierarchy: page title → filters/toolbar → primary data → secondary panels.
- Suitable for 8–12 hour daily professional use on 1440px and 1920px monitors.
- Support light and dark themes; default mockups in a refined dark theme with slate surfaces and emerald accent (slate-emerald). Also define light theme tokens.

DESIGN PRINCIPLES:
1. Information first — tables, forms, and status must be scannable in seconds.
2. One primary action per page header; secondary actions grouped.
3. Consistent project context always visible (active project name).
4. Blocks/towers always belong to one project — never show unrelated blocks.
5. Accessibility: WCAG AA contrast; focus rings; do not rely on color alone for status.
6. Same component language across all modules — do not invent a new look per module.

COLOR TOKENS (define as named styles):
- Neutral dark: bg #0B1120, surface #131C31, elevated #10172A, border #23314D
- Neutral light: bg #F8FAFC, surface #FFFFFF, border #E2E8F0
- Text: primary #F8FAFC (dark) / #0F172A (light); secondary #94A3B8 / #475569; label #64748B
- Accent (slate-emerald): #059669; hover #047857; subtle rgba(5,150,105,0.08)
- Optional alternate accents (document only): steel-blue, classic-purple — do not mix in one screen
- Semantic: success #10B981, warning #F59E0B, danger #EF4444, info steel-blue
- Sidebar dark: #334155; active item white text + 3px emerald left border

TYPOGRAPHY:
- Font family: Inter (or closest geometric sans). Avoid novelty display fonts.
- Scale: 12 caption, 13 secondary, 14 body (default), 16 section title, 20 page title, 24 hero/auth only
- Weights: 400, 500, 600, 700
- Line height: 1.4–1.5 body; tabular-nums for quantities, money, diameters, lengths
- Page titles never overpower brand mark in auth; in app, page title is the hero of the content area

SPACING & LAYOUT:
- 4px base grid: 4, 8, 12, 16, 24, 32
- Sidebar width 240px (collapsed 72px icon rail)
- Content max comfortable width with padding 24–32px; full-bleed tables OK
- Card radius 10–14px; inputs 6–10px; avoid pill-everything
- Shadows: subtle only (1–3px); no neon glow
- Breakpoints awareness: desktop ≥1200; tablet 768–1199; mobile shell separate later

COMPONENT LIBRARY TO DEFINE (show a Foundations board with examples):
1. Buttons: primary, secondary, ghost, danger, icon-only; sizes sm/md/lg; disabled/loading
2. Inputs: text, number, password, select, searchable select, textarea, date, checkbox, radio, switch, file
3. Form field: label, helper, error, required asterisk
4. Dropdown menus and comboboxes
5. Tabs (underline style for module sub-nav)
6. Table: header, sortable, row hover, selected row, sticky header, pagination, empty row
7. DataToolbar: search, filters, density, export
8. Cards: KPI card (clickable), content card — use sparingly; default to flat panels for data
9. Dialogs / modal: title, body, footer actions; destructive confirmation variant
10. Drawer (right) for detail panels
11. Toast / inline alert: success, error, warning, info
12. StatusBadge: active, inactive, trial, expired, suspended, draft, approved, rejected, in-progress, completed, on-hold, overdue
13. Progress bar and thin KPI sparkline style (simple SVG-friendly)
14. Breadcrumbs
15. Sidebar nav item, group label (Steel), accordion children
16. Project selector control (shows active project + chevron)
17. EmptyState, Skeleton loading, ErrorState, PermissionDenied
18. Avatar + user menu
19. Map placeholder style for geofence (Leaflet-like clean map chrome)
20. Icons: outline Lucide-style, 16/20/24; consistent stroke

NAVIGATION PATTERNS:
- Persistent left sidebar + main content
- Top of content: breadcrumbs then PageHeader (title, description, primary CTA)
- Active project always in sidebar selector
- Module permission: hide nav items user cannot access; show PermissionDenied if deep-linked

FORM & DESTRUCTIVE PATTERNS:
- Inline validation on blur/submit
- Confirm archive/delete with consequence text
- Never remove technical fields for aesthetics (diameters, mm lengths, PIN codes, lat/lng, costs)

SAMPLE DATA (illustrative only — not production):
- Company: “Horizon Constructions Pvt Ltd”
- Projects: “Greenfield Residences”, “Metro Hub Commercial”
- Blocks: “Tower A”, “Tower B”, “Podium”
- Users: Priya Sharma (Project Manager), Arjun Patel (Store Keeper)

OUTPUT:
Produce a Foundations / Design System desktop board that includes: color swatches, type scale, spacing, all components listed, status badges, sidebar + page header example, light and dark examples of a sample data table and a sample form. Label components clearly for reuse in later screens. Do not design full module pages in this prompt — foundations only.
```
