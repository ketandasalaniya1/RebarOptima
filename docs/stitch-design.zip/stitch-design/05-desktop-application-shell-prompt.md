# 05 — Desktop Application Shell Prompt (Google Stitch)

> Copy the `PROMPT` block into Stitch. Reference the Foundations board from prompt 04 as the visual system.

```PROMPT
Using the RebarOptima desktop design system (slate-emerald industrial SaaS, Inter, dense enterprise UI), design the DESKTOP APPLICATION SHELL and empty content frame for the authenticated workspace.

SCREEN 1 — Workspace shell (1920×1080 and 1440×900 compositions):
Left sidebar (240px):
- Brand mark “RebarOptima” at top (compact wordmark + small logo mark)
- Project selector directly under brand: shows “Greenfield Residences” with status pill Active; chevron opens project list
- Primary nav items with Lucide-style icons:
  Overview; Projects;
  Group “Steel”: Inventory, Ledger & Procurement, Run Optimizer, Batch History;
  BBS; Casting Management; Site Inventory; Real Estate CRM; Projects & Tasks; Drawing & Files; Petty Cash;
  Divider; Settings; User Management; Roles & Permissions; Activity Logs
- Active item: emerald left border + lighter bg
- Bottom: theme toggle (dark/light), user avatar “Priya S.” → Profile, Logout
- Collapsed rail variant (72px icons only) — show as second state

Main viewport:
- Top breadcrumbs: Home / Horizon Constructions / Greenfield Residences / Overview
- PageHeader placeholder: title “Overview”, short description, primary button slot
- Content canvas with subtle background (#0B1120) and a dashed empty content region labeled “Module content”

SCREEN 2 — Project selector open:
Dropdown/popover listing projects with search, status badges (active/inactive), “Create project” for Admin. Selecting a project must look like it updates the selector label and breadcrumbs. Note in annotation: “Switching project refreshes module data (projectEpoch).”

SCREEN 3 — Mobile-width web drawer (900px):
Same product, hamburger opens sidebar as overlay drawer; content full width. This is responsive web, not the native mobile app.

SCREEN 4 — Permission-filtered nav example:
Show a “Site Supervisor” variant of the sidebar with fewer items (hide Users, Roles, Settings, CRM, etc.) while keeping Overview, Projects, Inventory, Casting, etc. Annotation: Partner Admin allowlist is stricter in current product.

SCREEN 5 — Loading shell:
Sidebar skeleton + “Loading your projects…” centered card (matches bootstrap state).

SCREEN 6 — No-project shell:
No sidebar modules. Centered empty state: illustration-free; title “No projects yet”; CTA “Create project”; secondary Logout. Annotation: workspace modules require an active project.

CONSTRAINTS:
- Do not invent Attendance, GPS live tracking, or modules not listed.
- Do not put global search in the shell unless as a muted optional placeholder — product does not currently ship global search; prefer omitting it over faking it.
- No notifications inbox unless shown as a simple muted icon placeholder labeled “Future” — current product has activity logs page, not a notification bell center.
- Keep project context unmistakable.
- Match design tokens from the Foundations board.

OUTPUT: High-fidelity desktop shell screens listed above, dark theme primary, with one light-theme shell variant.
```
