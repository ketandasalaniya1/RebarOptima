# 06 — Desktop Module Prompts (Auth, Overview, Projects)

Related files:
- [06b — Steel, Optimizer, BBS, Casting](./06b-desktop-steel-bbs-casting-prompts.md)
- [06c — Site Inventory, CRM, PM](./06c-desktop-operations-crm-pm-prompts.md)
- [06d — Drawings, Petty Cash, Admin, Developer](./06d-desktop-drawings-admin-prompts.md)

Each `PROMPT` block is independent and ready to paste. Always reuse the RebarOptima shell + Foundations.

---

## Prompt 06.1 — Auth & gates

```PROMPT
Design RebarOptima desktop authentication and gate screens using the established design system (slate-emerald, Inter, industrial SaaS). Full-bleed atmospheric background with subtle construction/steel texture or soft gradient — not purple neon. Brand “RebarOptima” must be the hero signal on auth screens.

Screens:
1) Sign In (/login): centered card — email, password, Remember email checkbox, primary Sign in, link Create company account. Footer microcopy about construction operations software. Error state for invalid credentials. Loading button state.
2) Sign Up (/register): company name, admin first/last name, email, password, location/project name fields as a clean multi-section form; Submit creates company + trial. Link to Sign in.
3) Subscribe gate: blocked workspace message for suspended company or expired subscription; package cards FREE / BASIC / PRO / ENTERPRISE with limits (users, projects, storage) as illustrative; primary Contact / Upgrade CTA. No fake payment form fields beyond what a gate needs.
4) Developer login: restrained alternate chrome labeled “Developer console” — email/password only; not linked prominently from marketing.
5) Session timeout: return to Sign In with a small banner “Session expired due to inactivity (30 minutes).”

Do not invent social login or SSO unless as a disabled future placeholder. Output dark theme primary + one light Sign In.
```

---

## Prompt 06.2 — Overview dashboard

```PROMPT
Design the RebarOptima desktop Overview page inside the existing app shell (sidebar + breadcrumbs + project selector showing Greenfield Residences).

Purpose: project-scoped operational snapshot for PMs and engineers — not a marketing dashboard.

Layout:
- PageHeader: “Overview” / “Active project snapshot” / secondary “Refresh”
- KPI row (4–6 clickable cards): e.g. Steel stock lines, Remnant weight, Open batches, Scrap this month, Casting events this week, Open drawings — use plausible sample numbers with units (kg, mm, counts). Each card has a chevron implying navigation to Inventory / History / Casting / Drawings.
- Two-column mid section: “Recent batches” table (name, utilization %, scrap kg, date, status) and “Attention” list (low stock diameters, overdue casting cubes, pending drawing reviews) with StatusBadges.
- Bottom: quick actions — Run Optimizer, Add steel inward, Record casting event, Open Site Inventory.

States: loading skeletons; empty project data; error retry.
Roles: visible to all workspace users; Partner Admin sees steel-focused subset annotation.
Do not invent attendance check-ins or live GPS maps on Overview. Geofence is project config elsewhere.
Dark theme, dense, Linear-like clarity.
```

---

## Prompt 06.3 — Projects & blocks

```PROMPT
Design RebarOptima desktop Projects module screens using the app shell. Active project context remains in the sidebar selector; this page manages the company project catalog and canonical blocks.

SCREEN A — Projects list (/projects):
- Header: “Projects” + primary “Create project”
- Toolbar: search by name/address, filter by status (active/inactive) and type (Residential, Mixed-use, Commercial, Villa, Other)
- Card or table grid of projects: name, type badge, status, address + pincode, block count, partner count
- Selecting a project highlights it and opens Blocks panel

SCREEN B — Blocks panel (right drawer or lower split):
- Title “Blocks — Greenfield Residences”
- List editable block names (Tower A, Tower B, Podium) with display order, active status
- Actions: Add block, Rename, Archive (confirm). Enforce unique names; max 200 note in helper text
- Only Admin/Owner/developer can edit — show read-only state for Engineer

SCREEN C — Create project modal wizard (3 steps):
1) Details: name, address, 6-digit Indian pincode, latitude, longitude (map pin optional), project type, status
2) Blocks: numeric block count 0–200 generates name fields (Block 1…); user edits names
3) Review + Create
Validation errors on missing required fields and duplicate block names.

SCREEN D — Edit project modal (single page, no blocks step — blocks managed in panel)

SCREEN E — Geofence modal: Leaflet-style map, draw circle/polygon, list geofences, save. Feature permission projects.geofence.

SCREEN F — Assign Partner Admin modal: searchable user list, assigned chips, save.

Empty, loading, error, success toast states. Sample data only. Do not claim geofence validates worker attendance (not in product).
```

---

## End of file 06

Continue with 06b for Steel / BBS / Casting prompts.
