# 06b — Desktop Module Prompts (Steel, Optimizer, BBS, Casting)

Parent index: [06-desktop-module-prompts.md](./06-desktop-module-prompts.md)

---

## Prompt 06.4 — Steel Inventory & Ledger

```PROMPT
Design RebarOptima desktop Steel Inventory and Ledger pages inside the app shell. Active project: Greenfield Residences. Visual system: slate-emerald industrial SaaS.

SCREEN — Inventory (/inventory) with tabs: Stock list | Inward | Batch scrap | Scrap sales

Stock list:
- DataToolbar: search diameter/brand/vendor, filters (remnant yes/no, diameter), export
- Dense table columns: Diameter (mm), Length (mm), Qty, Weight (kg), Type of bar, Brand, Vendor, Cost/kg, Remnant badge, Actions
- Row actions: edit, delete (permission-gated)
- Empty state: “No steel stock for this project”

Inward tab: voucher-style form to add stock lines + submit; success returns to list.

Batch scrap tab: read-oriented table of scrap from cutting batches.

Scrap sales tab: create scrap sale form + history table.

SCREEN — Ledger & Procurement (/ledger) tabs: Ledger | Inward cost | Orders | Requests
- Financial/ops tables with dates, vendors, amounts (INR), status badges
- Export action
- Keep numbers tabular; clear debit/credit or cost columns as appropriate for a construction ledger UI

States for all: loading, empty, error, permission-denied (view-only). Do not invent modules. Dark theme primary.
```

---

## Prompt 06.5 — Cut Optimizer & Batch History

```PROMPT
Design RebarOptima desktop rebar cut optimizer flow using the app shell.

SCREEN 1 — Run Optimizer (/inputs):
- PageHeader “Run Optimizer”
- Left/main: select available stock lines (multi-select table from project inventory) and define required parts (diameter, length mm, quantity, shape/label)
- Sidebar or panel: kerf (mm), trim margin defaults (from settings), batch name
- Primary CTA “Optimize”
- Validation: need ≥1 stock and ≥1 part

SCREEN 2 — Results (/results):
- Summary KPIs: utilization %, scrap kg, bars used, remnant produced
- Layout diagrams or patterned cut lists per bar (clean schematic, not CAD)
- Tables of cutting patterns
- Actions: Save batch, Back to edit, Print/PDF affordance
- Success save → Batch History

SCREEN 3 — Batch History (/history):
- Filterable table: batch name, date, utilization, scrap, status, actions Edit / Delete / View
- Edit loads inputs with prior params

Include loading/optimizing progress state and empty history. Desktop-dense; this flow is desktop-primary.
```

---

## Prompt 06.6 — BBS (Bar Bending Schedule)

```PROMPT
Design RebarOptima desktop BBS module using the app shell. Hierarchy: Project → Block → Level → Member → Shapes/Instances. Use sample: Greenfield / Tower A / Level 12 / Beam B-12.

SCREEN A — BBS workspace (/bbs):
- Tabs: Hierarchy | Shapes | CAD
- Left tree: blocks → levels → members with completion % bars
- Main: member register table (type, display id, completion, status)
- Actions: Add block/level/member (modals), open shape library, open CAD for selected member
- Note: product also has routes /bbs/dashboard, /wizard, /shapes, /reports — design those as related screens in this set

SCREEN B — BBS Dashboard: KPI cards (members, shapes, tonnage estimate illustrative), progress by block

SCREEN C — Wizard: stepped form to add member rebars (bar mark, diameter, length, shape code, quantity) with review

SCREEN D — Shapes library: grid/list of shape templates with SVG-like shape previews, versioning (New version modal), archive/restore

SCREEN E — Reports: printable report layout (A4) with company/project header, member schedule table, totals — clean black/white friendly

SCREEN F — CAD chrome (desktop only): toolbar + canvas placeholder annotated “Existing Vue CAD island — match surrounding React chrome only; do not redesign CAD engine widgets to a new brand.”

States: empty hierarchy, loading tree, permission view-only. Keep terminology: BBS, bar mark, diameter, shape code.
```

---

## Prompt 06.7 — Casting Management

```PROMPT
Design RebarOptima desktop Casting Management (/casting) inside the app shell for project Greenfield Residences.

Module tabs: Structural | Events | Timeline | Recipes | Curing | Cubes | Track sheet

Structural: hierarchy manager + member register (member type, volumes, dimensions, status). Actions: create member modal.

Events: table of casting events; Create casting event modal (member/segments, planned volumes, schedule); assign segment recipes; MRS list affordance.

Timeline: horizontal/vertical timeline of casting events with status colors.

Recipes (company library): recipe list table; create/detail modals; version submit/approve/reject workflow badges (draft/submitted/approved/rejected). Ingredients list.

Curing: curing management view for pours.

Cubes: cube testing register (sample IDs, test dates, strength results, pass/fail).

Track sheet: dense production track sheet table suitable for site printing.

Additional modals: actual consumption, consumption approval, project stock register.

Dense construction UI; preserve engineering fields. Loading/empty/error/confirm destructive. Dark theme.
```
