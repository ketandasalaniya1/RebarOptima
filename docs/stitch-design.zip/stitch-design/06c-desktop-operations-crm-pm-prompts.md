# 06c — Desktop Module Prompts (Site Inventory, CRM, PM)

Parent index: [06-desktop-module-prompts.md](./06-desktop-module-prompts.md)

---

## Prompt 06.8 — Site Inventory (General Inventory)

```PROMPT
Design RebarOptima desktop Site Inventory module (/general-inventory) inside the app shell. Label must remain “Site Inventory” (not “Inventory”) to distinguish from Steel Inventory. Active project: Greenfield Residences.

Tabs: Overview | Materials | Inward | Outward | Returns | Transfers | Audit | Reports

Overview: KPI cards (SKUs, store count, low-stock alerts, open transfers) + recent movements feed.

Materials: master table of materials (code, name, unit, category, status) with create/edit; stock balances by store.

Inward / Outward / Returns / Transfers: transaction forms + history tables (store, qty, reference, photos optional placeholder, approved by).

Audit: verifications, adjustments, incidents lists with severity badges.

Reports: filterable summaries export/print.

Empty stores state with CTA “Add store”. Permission states for create/edit/delete. Dense tables with horizontal scroll acceptable. Dark industrial theme consistent with Foundations.
```

---

## Prompt 06.9 — Real Estate CRM

```PROMPT
Design RebarOptima desktop Real Estate CRM (/crm) inside the app shell for a residential project selling units.

IMPORTANT PRODUCT RULES:
- CRM has a module-level project selector in addition to the global shell project selector — show both, annotate “Product decision pending: unify selectors.”
- Customers and CRM settings are company-scoped; units, leads, visits, bookings are project-linked.

Tabs: Dashboard | Customers | Pipeline | Inventory | Visits & Tasks | Bookings | Payments | Reports | Settings

Dashboard: sales KPIs (leads, site visits, bookings, collections), funnel snapshot.

Customers: searchable table (name, phone, email, source, owner); detail drawer.

Pipeline: kanban by lead stage (illustrative stages matching CRM enums: new → contacted → visit → negotiation → booked / lost).

Inventory (units): building/block chessboard or grid of unit availability (available, held, booked, sold) with filters by floor/BHK/facing.

Visits & Tasks: split lists — upcoming site visits, follow-up tasks with due dates and assignees.

Bookings: booking table + create booking form (customer, unit, amount, status).

Payments: schedules and receipts tables (INR), status badges.

Reports: simple charts + summary tables (do not invent unrealistic revenue).

Settings: sources, statuses, notification toggles as clean forms.

States: empty pipeline, loading, errors. Premium but practical — not a consumer real-estate marketing site.
```

---

## Prompt 06.10 — Projects & Tasks (CPM / PM)

```PROMPT
Design RebarOptima desktop Projects & Tasks module (/project-management) inside the app shell.

IMPORTANT: This module currently uses its own project dropdown (pm projects) that may differ from the global ProjectSelector — show a clear in-page project select and annotate the inconsistency for product resolution. Still display global selector in shell.

Views/tabs: Overview | Projects | Tasks | Gantt | Manpower | Calendar | DPR | Quality

Overview: CPM KPIs — progress %, delayed tasks, open inspections, manpower today.

Projects: PM project list/detail (name, baseline dates, status).

Tasks: task table/board — WBS-ish name, predecessors note, start/finish, % complete, owners; create/edit task drawer.

Gantt: desktop Gantt chart with bars, today line, critical path highlight (simplified but professional).

Manpower: allocation table by trade/date.

Calendar: month/week calendar of tasks and milestones.

DPR (Daily Progress Report): form to submit daily progress + history list.

Quality: inspections list, pass/fail, punch items; delay and reschedule modals with approval tone.

Permissions: view vs create vs reschedule vs quality vs cost. Include a Cost/Productivity secondary panel or tab if space allows (component exists in product).

Dense PM software aesthetic (think construction Primavera-lite clarity, not consumer kanban toys).
```
