# 06d — Desktop Module Prompts (Drawings, Petty Cash, Admin, Developer)

Parent index: [06-desktop-module-prompts.md](./06-desktop-module-prompts.md)

---

## Prompt 06.11 — Drawing & Files

```PROMPT
Design RebarOptima desktop Drawing & Files module (/drawings) inside the app shell.

Subviews to design as a coherent module:
1) Dashboard — counts by discipline, pending reviews, recent uploads
2) Drawing register — dense table: drawing no., title, discipline, revision, status (draft/for review/approved/superseded), updated
3) Revision history — timeline of revisions with approve/reject actions
4) Discipline library — company disciplines CRUD
5) Document transmittals — create transmittal packages, recipient list, status
6) Activity log — module activity
7) Module settings & permissions — roles for drawings module
8) PDF viewer chrome — clean viewer with zoom/download
9) CAD viewer chrome — annotate that inner CAD may be Vue/Element Plus; outer page chrome must match RebarOptima React shell

Toolbar: search, filter discipline/status, Upload drawing. Empty register CTA. Project-scoped drawings with company disciplines. Dark theme consistency. Do not invent a second brand for CAD.
```

---

## Prompt 06.12 — Petty Cash

```PROMPT
Design RebarOptima desktop Petty Cash (/petty-cash) inside the app shell for site float management.

Layout:
- PageHeader with balance KPI (illustrative INR) and “Add transaction”
- Filters: date range, site, person, category, credit/debit
- Ledger table: date, site, person, category, description, credit, debit, balance, receipt thumb, actions
- Modals/drawers: New transaction (amount, type, category, person, site, notes, photo receipt upload), Manage sites, Manage persons, Manage categories

Empty state and permission view-only. Keep it fast for daily site accountants/supervisors. Consistent tokens.
```

---

## Prompt 06.13 — Settings, Users, Roles, Logs, Profile

```PROMPT
Design RebarOptima desktop administration and account screens inside the app shell.

1) Settings (/settings): sections for Appearance (theme mode light/dark, color theme slate-emerald / steel-blue / classic-purple), Optimizer defaults (kerf, trim margin), Storage quota meter vs plan, Scrap rules table CRUD. Save bars.

2) Users (/users): admin table — name, email, role, assigned projects chips, active status; Create/Edit user drawer; deactivate confirm. Filter by project assignment.

3) Roles & Permissions (/roles): role list + editor. Matrix of modules × features toggles; dataScope select organization|project; system roles read-only vs custom editable. Include modules: overview, inventory, optimizer, history, ledger, scrapSales, casting, generalInventory, crm, drawings, pettyCash, projectManagement, projects, users, roles, settings, activityLogs. Note BBS gating ambiguity in annotation.

4) Activity Logs (/activity-logs): filterable audit table (actor, action, module, project, timestamp); pagination; export.

5) Profile (/profile) tabs: Identity | Preferences | Security (change password) | My activity. Avatar, mobile number, name.

PermissionDenied state for non-admins on Users/Roles. Sample data only.
```

---

## Prompt 06.14 — Developer console

```PROMPT
Design RebarOptima Developer Console (/developer) as a separate desktop admin shell (not the company sidebar). Restrained platform-ops aesthetic still using the same tokens.

Top bar: “RebarOptima Developer” + signed-in developer identity + logout.

Tabs: Companies | Packages | Subscriptions | Audit

Companies: table of tenants — name, status (active/inactive/suspended), created; detail drawer to set status; soft-delete confirm.

Packages: FREE/BASIC/PRO/ENTERPRISE cards/table with module flags and limits (maxUsers, maxProjects, maxStorageMB); edit.

Subscriptions: assign package to company, trial/active/expired, dates, module/feature overrides UI.

Audit: platform audit log table.

Do not expose secrets or real credentials. Illustrative data only. Desktop-only.
```
