# 07 — Mobile Design System Prompt (Google Stitch)

> Copy the `PROMPT` block into Stitch. Mobile is a **companion product design** — there is no React Native app in the RebarOptima repo today.

```PROMPT
Create a MOBILE design system for RebarOptima, a construction operations SaaS. Platforms: Android and iPhone, portrait primary, widths 360–430px. This is a field companion to the desktop web product — same brand, colors, terminology, project/block rules, and roles — but mobile-native layouts (not a shrunk desktop).

IMPORTANT CONSTRAINTS FROM THE REAL PRODUCT:
- No attendance / GPS check-in APIs ship today — do NOT make check-in a core system component. Geofences exist as project configuration only.
- No native app code exists yet; design for a future React Native or responsive PWA companion.
- Desktop-only workflows (full cut optimizer CAD, role matrix editor, developer console) stay out of the mobile component set.

BRAND & TOKENS:
- Same slate-emerald system as desktop: dark bg #0B1120, surface #131C31, accent #059669, danger/warning/success identical meanings.
- Typography: Inter; body 16px minimum for primary reading; 13–14 secondary; page titles 20.
- Touch targets ≥44×44px. Comfortable thumb zones.
- Spacing 8px grid; bottom nav height ~56–64px; safe areas for notches.
- Corner radius 10–12; sheets use large top radius.
- Icons Lucide-outline 24px in nav, 20 in lists.

MOBILE COMPONENTS TO DEFINE:
1) Bottom navigation (max 5 items)
2) Top app bar (title, back, context project chip, overflow)
3) Project switcher bottom sheet (searchable)
4) Block picker sheet (filtered by active project only)
5) List rows / card rows for field data (replace wide tables)
6) Sticky primary CTA bar
7) Text fields with mobile keyboards (numeric, tel, email)
8) Searchable select sheets
9) Bottom sheets (actions, filters, confirm)
10) Dialogs (destructive confirm)
11) Status chips
12) Empty / loading skeleton / offline banner / error retry
13) Photo attachment row (for petty cash receipts etc. where product supports photos)
14) Segmented controls / mobile tabs (scrollable)
15) FAB only when it does not conflict with bottom nav
16) Permission denied full-screen
17) Biometric affordance optional placeholder — do not require (not verified in product)

NAV PRINCIPLES:
- Bottom nav for highest-frequency field destinations only.
- Overflow “More” for secondary modules.
- Always show active project chip in the top bar.
- Back stack clear; avoid deep hamburger-only IA.

OUTPUT: A mobile foundations board — colors, type, components, example list, example form, example sheet — dark theme primary + light variant. No full app flows yet.
```
