# 08 — Mobile Application Shell Prompt (Google Stitch)

```PROMPT
Design the RebarOptima MOBILE application shell using the mobile design system (slate-emerald, Inter, 44px targets). Portrait phone frames (iPhone 14/15 and common Android 412px).

SHELL STRUCTURE:
Top app bar:
- Left: menu or back
- Center/Left title
- Right: circular project chip “Greenfield” tapping opens Project switcher sheet; overflow ⋮ for Profile / Logout

Bottom navigation (5 items max):
1) Home (Overview)
2) Tasks (PM tasks / DPR entry point)
3) Inventory (hub: Steel stock view + Site Inventory shortcut)
4) Site (Casting + Petty Cash shortcuts inside)
5) More (BBS browse, CRM visits, Drawings PDF, Settings)

Do NOT put Users, Roles, Developer, full Optimizer, or Gantt in bottom nav.

SCREENS:
1) Shell on Home with sample KPI peek
2) Project switcher bottom sheet — searchable projects, status badges, current checkmark; Admin sees Create project
3) More sheet / More tab grid of secondary modules with permission-hidden items ghosted or omitted
4) Offline banner state (“You’re offline — showing last synced data”) as UI pattern even if sync engine TBD — label as recommended pattern, not verified backend
5) Session loading “Loading projects…”
6) No-project empty state with Create project CTA
7) Subscribe/blocked subscription full screen gate

ROLE VARIANTS:
- Store Keeper shell: Inventory emphasized
- Sales Executive: CRM visits emphasized in More/Home shortcuts
- Site Supervisor: Tasks + Site emphasized

Annotate: Global project context must match desktop business rules; blocks pickers only show blocks for selected project. No live attendance check-in in shell.
```
