# 09 — Mobile Module Prompts

> Each prompt is ready to paste. Reuse mobile shell + foundations. Classify workflows per inventory (full / simplified / read-only / desktop-only).

---

## Prompt 09.1 — Auth & account (mobile)

```PROMPT
Design RebarOptima mobile auth and profile screens (portrait).

1) Sign In — brand hero, email, password, Sign in, Create account link, error/loading
2) Sign Up — multi-step compact form (company → admin user → confirm)
3) Subscribe gate — blocked state with package summary
4) Profile — identity, change password, appearance (light/dark), logout
5) Permission denied — simple full screen

No social login. No developer console on mobile. Same tokens as mobile foundations.
```

---

## Prompt 09.2 — Home, projects, blocks (mobile)

```PROMPT
Design RebarOptima mobile Home and Projects flows.

HOME: simplified dashboard — active project chip, 4 KPI tiles (steel lines, open tasks, today’s casting, low site stock), shortcut row (Inward steel, Site outward, DPR, Petty cash), attention list.

PROJECTS LIST: searchable cards (name, type, status, blocks count). Tap opens Project detail.

PROJECT DETAIL: address, type, status, map thumbnail (static), Blocks list, actions Edit (admin), View geofences (read-only map).

BLOCKS: list + add/rename sheets for admin; archive confirm. Unique names; belong only to this project.

PROJECT SWITCHER integration from shell. Empty and loading states. Do not add attendance check-in.
```

---

## Prompt 09.3 — Steel & site inventory (mobile)

```PROMPT
Design mobile inventory workflows for RebarOptima.

STEEL (simplified):
- Stock list as cards/rows: Ø12mm × 12000mm — qty, kg, remnant chip; tap detail
- Filters sheet (diameter, remnant)
- Inward form: numeric-friendly fields for diameter, length mm, qty, vendor, cost/kg
- Scrap sales: read list + simple create
- Batch history: read-only cards with utilization; no full optimizer UI (annotate Desktop-only for Run Optimizer)

SITE INVENTORY (full field ops):
- Stores list → stock balances
- Inward / Outward / Transfer / Return quick actions with sticky Submit
- Materials search
- Low stock alerts

Replace desktop tables with scannable lists. Offline error on submit. Project context required.
```

---

## Prompt 09.4 — BBS & casting (mobile)

```PROMPT
Design mobile BBS browse + Casting field update screens for RebarOptima.

BBS (simplified / read-heavy):
- Hierarchy navigation: Blocks → Levels → Members
- Member detail: completion %, bar schedule list (mark, Ø, length, qty, shape code)
- Shapes: read-only previews
- Annotate: CAD editor and complex wizard = Desktop-only; optional “Request edit on desktop”

CASTING (simplified full for site):
- Events list for project/block
- Event detail + update status
- Record actual consumption (quantities)
- Curing list and cube test result entry (pass/fail, strength)
- Recipes: read-only reference

Use bottom sheets for forms; large numeric inputs. No invented GPS pour validation.
```

---

## Prompt 09.5 — CRM field + PM field (mobile)

```PROMPT
Design mobile field CRM and PM screens for RebarOptima.

CRM (full for visits/tasks; simplified elsewhere):
- Today’s visits list with call/navigate affordances (maps link pattern)
- Visit check outcome form (visited / no-show / notes) — this is CRM site visit, NOT workforce attendance
- Follow-up tasks list with complete action
- Customer quick view
- Unit inventory: simplified availability list by floor (not full chessboard)
- Bookings/payments: read-only summaries
- Pipeline kanban: optional simplified; annotate desktop for power use

PM (full for tasks/DPR; gantt desktop):
- My tasks list (due, priority, % complete) — update progress sheet
- Submit DPR form (date, work done, manpower, blockers)
- Quality inspection checklist mobile form
- Gantt: read-only banner “Open on desktop”
- Show in-page project context; annotate possible divergence from global selector as in desktop product

Keep role-aware: Sales vs Supervisor home shortcuts differ.
```

---

## Prompt 09.6 — Drawings, petty cash, more (mobile)

```PROMPT
Design remaining RebarOptima mobile module screens.

DRAWINGS (simplified):
- Register list filter by discipline/status
- Drawing detail metadata
- PDF viewer chrome (pinch zoom)
- Transmittals read-only
- Annotate CAD = desktop

PETTY CASH (full):
- Balance header
- Transaction list
- Add credit/debit with photo receipt capture UI
- Category/person/site selectors as sheets

MORE / SETTINGS:
- Links to modules user can access
- Theme toggle
- Open desktop-only admin note for Users/Roles

NOTIFICATIONS / ACTIVITY (simplified):
- Recent activity list (from activity logs concept) — not a fake push notification center unless labeled future

All screens: loading, empty, error, offline submit failure, success toast. Consistent project chip.
```
