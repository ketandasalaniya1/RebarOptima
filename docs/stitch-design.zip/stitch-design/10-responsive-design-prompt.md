# 10 — Responsive Design Prompt (Google Stitch)

```PROMPT
Create a responsive behavior specification board for RebarOptima spanning desktop web, tablet web, and the mobile companion app. Same product identity (slate-emerald, Inter, project→block rules, RBAC) but platform-appropriate IA.

BREAKPOINTS:
- Desktop ≥1200px: persistent 240px sidebar (collapsible to 72px), multi-column tables, modals centered
- Tablet 768–1199px: sidebar becomes drawer; tables keep horizontal scroll; prefer 1–2 column forms; Gantt remains usable or offers simplified list fallback
- Phone ≤767px web: treat as transitional — hamburger drawer; warn that primary field UX is the mobile companion shell (bottom nav), not cramped desktop tables

ADAPTATION RULES:
1) Navigation: desktop sidebar ≠ mobile bottom nav. Do not force all desktop links into bottom nav.
2) Tables → mobile lists/cards; keep critical columns only.
3) Page headers: desktop title+CTA row; mobile title + sticky bottom CTA.
4) Filters: desktop inline toolbar; mobile filter sheet.
5) Project selector: always visible; desktop dropdown; mobile bottom sheet.
6) Blocks: always filtered by selected project on every breakpoint.
7) Complex creators (optimizer, role matrix, geofence draw, Gantt edit, CAD): desktop-primary; mobile shows read-only or “Continue on desktop”.
8) Modals: desktop dialogs; mobile full-screen or sheets.
9) Touch: ≥44px on tablet/phone web controls.
10) Density: desktop dense; mobile airier but still professional.

OUTPUT: Three annotated frames of the SAME “Site Inventory Materials” feature at desktop, tablet, and phone companion — proving consistent tokens/terminology with different layouts. Add a short written rules legend on the board.
```
