# 11 — Cross-Screen Consistency Prompt (Google Stitch)

```PROMPT
You are refining an existing set of RebarOptima screens (desktop shell, module screens, mobile shell, mobile modules) to enforce ONE product language.

AUDIT AND FIX FOR CONSISTENCY:
- Colors: only slate-emerald neutrals + semantic tokens; remove random purples/glows introduced per screen
- Typography: Inter scale identical; page titles 20 desktop / 20 mobile; body 14 desktop / 16 mobile
- Component sizes: primary buttons same height per platform; inputs aligned; badge radii consistent
- Navigation: desktop sidebar labels match mobile More-menu labels (Steel Inventory vs Site Inventory naming preserved)
- Terminology: Project, Block/Tower, BBS, Casting, DPR, Inward, Outward, Remnant, Utilization — identical spelling/casing
- Project context: every operational screen shows the same active project name pattern
- Blocks: never list blocks from another project
- Status styles: reuse the same StatusBadge colors for active/inactive/approved/rejected/overdue/etc.
- Spacing: 8px grid adherence; align card paddings
- Icons: one Lucide-style set; unique icons for Projects vs BBS vs CRM (no duplicate Building icon meaning three things without differentiation)
- Empty/loading/error patterns shared
- Desktop vs mobile: same business rules; different layout only
- Remove any invented Attendance check-in screens if they appeared
- Remove fake global notification centers if not labeled Future
- CRM/PM local project selectors: if present, visually mark as “Module project” vs “Workspace project” until product unifies

OUTPUT: A consistency changelog list + corrected key screens (shell, Overview, Projects, one Steel, one CRM, mobile Home, mobile Inventory). State which screens were changed.
```
