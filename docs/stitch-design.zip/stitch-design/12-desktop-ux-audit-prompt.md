# 12 — Desktop UX & Accessibility Audit Prompt (Google Stitch)

```PROMPT
Perform a UX and accessibility audit of the generated RebarOptima DESKTOP screens against this checklist. Produce annotated findings (severity P0/P1/P2) and suggest concrete visual fixes. Do not invent new product modules.

CHECKLIST:
1. Missing screens vs inventory: Sign In/Up, Subscribe, No project, Overview, Projects+Blocks wizard, Inventory tabs, Ledger, Optimizer+Results+History, BBS suite, Casting tabs, Site Inventory tabs, CRM tabs, PM views, Drawings, Petty Cash, Settings, Users, Roles, Activity Logs, Profile, Developer console, Geofence, Assign partner
2. Missing states: loading, empty, error, success, confirm destructive, permission denied, subscription gate
3. Navigation: sidebar labels unique; Steel group clear; Site Inventory ≠ Inventory; breadcrumbs present; project selector always visible
4. Visual hierarchy: one primary CTA; tables scannable; KPIs actionable
5. Forms: labels, errors, required fields; project create includes blocks step; pincode/lat-lng visible
6. Contrast: WCAG AA on dark and light; badge text readable
7. Focus/keyboard: visible focus rings on controls (annotate)
8. Dense tables: sticky header, tabular numbers, horizontal scroll affordance
9. Project/block correctness: blocks tied to project; switch project messaging
10. Dual selectors: CRM/PM local project select called out if confusing
11. CAD/drawings chrome matches shell
12. No attendance/GPS worker tracking invented
13. Partner Admin limited nav represented
14. Destructive actions confirmed

OUTPUT: Audit board with callouts + prioritized fix list. Optionally regenerate the top 5 P0 screens with fixes applied.
```
