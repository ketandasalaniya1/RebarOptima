# 13 — Mobile UX Audit Prompt (Google Stitch)

```PROMPT
Audit the generated RebarOptima MOBILE screens for field usability and accessibility. Annotate issues P0/P1/P2 and propose fixes. Mobile is a companion design — no native app exists in repo.

CHECKLIST:
1. Bottom nav ≤5 items; frequent field tasks reachable in ≤2 taps
2. Touch targets ≥44×44; thumb-zone primary CTAs
3. Active project chip always visible; switcher is a searchable sheet
4. Blocks picker only shows current project blocks
5. Tables replaced with lists/cards; no microscopic desktop tables
6. Forms: correct keyboards, sticky submit, validation visible
7. States: loading, empty, error, offline banner, success, permission denied, no-project, subscribe
8. Classification respected: optimizer CAD/Gantt/roles/developer are desktop-only with clear messaging
9. CRM site visit ≠ workforce attendance — wording must not say “check in to site geofence” as time-attendance
10. Photo capture UI only where product supports attachments (e.g. petty cash)
11. Contrast AA; dynamic type tolerance noted
12. Safe areas / notches respected
13. Back navigation clear; no dead ends
14. Role variants (store keeper / supervisor / sales) still coherent
15. Terminology matches desktop exactly

OUTPUT: Mobile audit board + fix list; regenerate worst P0 screens.
```
