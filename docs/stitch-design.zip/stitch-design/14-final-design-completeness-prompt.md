# 14 — Final Design Completeness Prompt (Google Stitch)

```PROMPT
Compare the full set of generated RebarOptima screens to this coverage checklist. Produce a completeness matrix and list gaps. Do not add unrelated SaaS features (HRIS, payroll, live GPS attendance, etc.).

DESKTOP MUST EXIST:
Auth Sign In/Up; Subscribe; Developer login/console; No project; Bootstrap loading; Shell (sidebar, project selector, breadcrumbs, user menu); Overview; Projects list; Blocks panel; Create project wizard; Edit project; Geofence; Assign partner; Inventory (4 tabs); Ledger (4 tabs); Optimizer inputs; Results; Batch history; BBS workspace + dashboard + wizard + shapes + reports; Casting (7 tabs + key modals); Site Inventory (8 tabs); CRM (9 tabs); PM (overview/projects/tasks/gantt/manpower/calendar/dpr/quality); Drawings suite; Petty Cash; Settings; Users; Roles; Activity Logs; Profile.

MOBILE MUST EXIST:
Sign In/Up; Subscribe; Profile; Home; Project list/detail/switcher; Blocks; Steel stock + inward (simplified); Site inventory ops; BBS browse; Casting field updates; CRM visits/tasks; PM tasks/DPR/quality; Drawings PDF list; Petty cash + receipt; More/settings. Desktop-only notices for optimizer CAD, gantt edit, users/roles, developer.

SHARED RULES VERIFIED:
Same brand tokens; project→block association; RBAC-aware nav; no invented attendance product; Steel vs Site Inventory naming; CRM/PM selector inconsistency documented if shown.

OUTPUT:
1) Coverage table Screen × Desktop × Mobile × Status (Present / Partial / Missing)
2) Disconnected navigation findings
3) Missing states findings
4) Inconsistent UI patterns findings
5) Recommended manual Figma follow-ups
```
