# 15 — Google Stitch Generation Guide

## Before you start

1. Read [01-codebase-audit.md](./01-codebase-audit.md) and [02-screen-inventory.md](./02-screen-inventory.md).
2. Skim [17-unresolved-design-decisions.md](./17-unresolved-design-decisions.md) so you do not “resolve” open questions inside Stitch by inventing rules.
3. Create a Stitch project named **RebarOptima Design System**.
4. Expect **many generations** — Stitch will not hold the entire product in one prompt reliably. Work modularly.
5. Prefer attaching/referencing the previous Foundations or Shell output as a visual reference when Stitch supports it.

## Recommended paste order

| Step | File | Prompt | Reference previous? |
|------|------|--------|---------------------|
| 1 | 04 | Desktop design system | — |
| 2 | 05 | Desktop shell | Yes — Foundations |
| 3 | 06 Prompt 06.1 | Auth & gates | Foundations |
| 4 | 06 Prompt 06.2–06.3 | Overview + Projects | Shell |
| 5 | 06b 06.4–06.5 | Steel + Optimizer | Shell |
| 6 | 06b 06.6–06.7 | BBS + Casting | Shell |
| 7 | 06c 06.8–06.10 | Site Inv + CRM + PM | Shell |
| 8 | 06d 06.11–06.14 | Drawings + Admin + Dev | Shell |
| 9 | 07 | Mobile design system | Desktop Foundations (tokens) |
| 10 | 08 | Mobile shell | Mobile foundations |
| 11 | 09 | Mobile modules (09.1→09.6) | Mobile shell |
| 12 | 10 | Responsive triad | Desktop + mobile samples |
| 13 | 11 | Cross-screen consistency | All key screens |
| 14 | 12 | Desktop UX audit | Desktop set |
| 15 | 13 | Mobile UX audit | Mobile set |
| 16 | 14 | Completeness | Full set + matrix |

Update [03-screen-coverage-matrix.md](./03-screen-coverage-matrix.md) after each step.

## When to reuse vs regenerate

| Situation | Action |
|-----------|--------|
| Same shell, new module page | Reuse shell as reference; generate module content only |
| Same module, different tab | Generate as a set in one prompt if small; else separate with “match previous tab chrome” |
| Visual drift appears | Run prompt 11 before more modules |
| Stitch ignores constraints | Shorten prompt; paste only one screen family; restate tokens in 5 lines |
| CAD / Gantt / complex charts | Accept schematic UI; refine in Figma manually |

## Limitations (do not over-claim)

- Stitch may truncate long prompts — split further if outputs ignore later screens.
- Stitch may not maintain unlimited project memory — re-attach Foundations often.
- Automatic “export entire app to editable Figma with components” is **not assumed**. See [16-figma-handoff-guide.md](./16-figma-handoff-guide.md).
- Generated UIs are **design intent**, not wired to the Express API.
- Sample data in prompts is fictional.

## Quality bar per generation

- [ ] Dark slate-emerald look matches Foundations  
- [ ] Active project visible  
- [ ] No attendance product invented  
- [ ] Steel vs Site Inventory labels correct  
- [ ] States (empty/loading/error) present or explicitly deferred  
- [ ] Screenshot saved / named per matrix ID  

## Naming exported frames

`RO-D-{module}-{screen}-v{n}` desktop, `RO-M-{module}-{screen}-v{n}` mobile.  
Examples: `RO-D-projects-blocks-panel-v1`, `RO-M-petty-add-txn-v2`.
