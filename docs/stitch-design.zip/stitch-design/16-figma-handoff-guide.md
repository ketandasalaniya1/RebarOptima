# 16 — Figma Handoff Guide

## What is verified vs unverified

| Method | Status |
|--------|--------|
| Manual recreate in Figma from Stitch screenshots / exports | **Supported** (always works) |
| Copy/paste images into Figma as reference frames | **Supported** |
| Stitch → Figma official one-click editable component library | **Unverified** — do not assume it exists for your Stitch version; check Stitch’s current help docs at time of use |
| Third-party “AI to Figma” plugins | **Unverified** — evaluate security before uploading product screens |
| html.to.design / similar from implemented app | Possible later from Vite app, but **out of scope** for this design package |

If Stitch offers an export (PNG, PDF, or Figma link) in your account, use it as a **starting point**, then rebuild components properly in Figma for production design ops.

## Recommended Figma file structure

```
RebarOptima — Product Design
├── 00 Cover & README
├── 01 Foundations
│   ├── Color
│   ├── Type
│   ├── Spacing
│   ├── Icons
│   └── Components
├── 02 Desktop — Shell
├── 03 Desktop — Auth & Admin
├── 04 Desktop — Projects & Blocks
├── 05 Desktop — Steel & Optimizer
├── 06 Desktop — BBS & Casting
├── 07 Desktop — Site Inventory
├── 08 Desktop — CRM
├── 09 Desktop — PM / CPM
├── 10 Desktop — Drawings & Petty Cash
├── 11 Mobile — Shell & Nav
├── 12 Mobile — Modules
├── 13 Responsive Specs
├── 14 Prototypes
└── 15 Design Review
```

## Naming conventions

- Pages: `D/` or `M/` prefix in frame names matching Stitch exports (`RO-D-…`, `RO-M-…`)
- Components: `Button/Primary`, `Badge/Status/Active`, `Nav/SidebarItem`, `Selector/Project`
- Variables: map to tokens in Foundations (`color/bg/canvas`, `color/accent/default`, …)
- Modes: `Dark / Light` as variable modes if using Figma variables

## Transfer workflow

1. Generate Foundations in Stitch → screenshot/export → rebuild as Figma Variables + Components (do not leave only flat bitmaps).
2. Shell next → create Desktop Shell and Mobile Shell components with slots for page content.
3. For each module: place Stitch output on a **Reference** subpage (locked), recreate with real components on **Production** subpage.
4. Prototype critical flows only: Sign in → Overview → Switch project → Inventory inward; Mobile DPR submit; Petty cash + photo.
5. Design Review page: embed unresolved decisions from doc 17 as sticky annotations.
6. Hand to engineering with links to routes in [02-screen-inventory.md](./02-screen-inventory.md) — designs must map to existing views, not greenfield routes, unless product agrees.

## Manual correction expected

Expect to manually fix in Figma: Gantt fidelity, BBS shape SVGs, CAD chrome, Leaflet map, unit chessboard, print report layouts, and any Stitch hallucinated modules.

## Review checklist before eng handoff

- [ ] Components used (not only images)  
- [ ] Dark/light variables  
- [ ] Desktop + mobile for agreed scope  
- [ ] Matrix IDs labeled on frames  
- [ ] Open questions linked to doc 17  
- [ ] No secrets/production data in file  
