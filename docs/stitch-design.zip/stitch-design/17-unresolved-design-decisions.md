# 17 — Unresolved Design Decisions

These questions **cannot** be answered confidently from source alone. Stitch prompts document both sides where needed; do **not** silently invent a single business rule in final UI copy without a product owner decision.

| ID | Question | Why it matters | Evidence |
|----|----------|----------------|----------|
| U1 | Should **global ProjectSelector** be the only project context for CRM and PM? | Dual selectors confuse “which project am I in?” and can show mismatched data. | `ProjectManagementPage` local select; CRM `selectedProjectId` vs shell `selectedProject` |
| U2 | Which **BBS surface is canonical** — monolithic `BBSPage` or routed `bbs-dashboard/wizard/shapes/reports`? | Nav only highlights `bbs`; duplicate IA risks divergent designs. | `App.jsx` mounts both families; SideNavbar single BBS item |
| U3 | Should **Partner Admin** frontend allowlist match backend role grants (incl. GI)? | Users may have API access to modules hidden in nav (or vice versa after role edits). | `PARTNER_ALLOWED_MODULES` vs `DEFAULT_SYSTEM_ROLES` Partner permissions |
| U4 | Is **BBS** gated by `PLATFORM_MODULES`? Key missing from catalog. | Roles UI / subscription packages may omit BBS; design permission states unclear. | `PLATFORM_MODULES` in `main.ts` vs SideNavbar `moduleKey: 'bbs'` |
| U5 | Is a **native mobile app** planned, or only responsive web? | Entire mobile package is design-only today. | No RN/Expo in repo |
| U6 | Are **geofences** only metadata, or future **attendance**? | Must not market check-in as shipped. | Geofence CRUD exists; attendance `out_of_scope` in matrix; no check-in APIs |
| U7 | After project unification, do module catalogs (`bbs_projects`, etc.) remain visible in UI? | Affects whether modules show a second project picker permanently. | `module-project-adapter.ts`; casting refuses local create |
| U8 | Should **global search** and **notification bell** exist? | Shell prompt omits them as unverified. | No global search feature found; activity logs page exists instead |
| U9 | **RolesPage** module labels vs newer modules (CRM, PM, petty cash, BBS) completeness? | Admin may not toggle all real modules. | Roles UI may lag `PLATFORM_MODULES` / nav |
| U10 | DrawingsPage **load integrity** — is the register fully usable? | Designing happy-path drawings may overstate readiness. | Explore agent noted possible mid-merge corruption |
| U11 | Default theme for marketing mockups: product defaults **dark**, many SaaS decks prefer light. | Stitch default choice. | `App.jsx` default `themeMode` dark |
| U12 | Multi-company users? | Org switcher design. | Signup creates one company per admin; no multi-org membership API found |
| U13 | Subscribe page payment / Razorpay / Stripe? | Billing UI depth. | Packages + developer assign; full checkout not verified as primary UX |
| U14 | Mobile offline sync — required or optimistic UI only? | Field ops expectations. | No offline sync engine verified |

## How prompts handle these

- Show both patterns with **annotations** (U1, U2).  
- Design Partner Admin limited nav as **current UX intent** (U3).  
- Exclude attendance as shipped (U6).  
- Mobile labeled **companion design** (U5).  
- Omit fake search/notifications unless marked Future (U8).

## Decision log (fill in)

| ID | Decision | Owner | Date |
|----|----------|-------|------|
| | | | |
