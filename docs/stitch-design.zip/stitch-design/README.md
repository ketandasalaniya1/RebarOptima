# RebarOptima — Google Stitch Design Prompt Package

Source-code-informed UI/UX design package for generating **desktop** and **mobile companion** screens in Google Stitch, then refining in Figma.

**This package does not modify application source.** It documents the existing Vite/React + Express product and provides ready-to-paste prompts.

---

## Overview

RebarOptima is a multi-tenant construction SaaS: **company → projects → blocks**, with modules for steel inventory/optimization, BBS, casting, site inventory, CRM, CPM tasks, drawings, petty cash, and admin/RBAC. There is **no React Native app** in this repository; mobile prompts design a companion experience from verified web capabilities.

## Recommended workflow

1. Read audit + inventory (`01`, `02`, `03`, `17`).
2. Paste prompts into Stitch in the order in [`15-stitch-generation-guide.md`](./15-stitch-generation-guide.md).
3. Run consistency + UX audits (`11`–`14`).
4. Transfer/rebuild in Figma per [`16-figma-handoff-guide.md`](./16-figma-handoff-guide.md).
5. Track progress in the coverage matrix (`03`).

## File index

| File | Purpose |
|------|---------|
| [01-codebase-audit.md](./01-codebase-audit.md) | Verified architecture, modules, roles, project/blocks, UX issues |
| [02-screen-inventory.md](./02-screen-inventory.md) | Screen-by-screen inventory + mobile classification |
| [03-screen-coverage-matrix.md](./03-screen-coverage-matrix.md) | Desktop/mobile/prompt/review tracking |
| [04-desktop-design-system-prompt.md](./04-desktop-design-system-prompt.md) | Master desktop Foundations prompt |
| [05-desktop-application-shell-prompt.md](./05-desktop-application-shell-prompt.md) | Sidebar, project selector, shell |
| [06-desktop-module-prompts.md](./06-desktop-module-prompts.md) | Auth, Overview, Projects |
| [06b-desktop-steel-bbs-casting-prompts.md](./06b-desktop-steel-bbs-casting-prompts.md) | Steel, Optimizer, BBS, Casting |
| [06c-desktop-operations-crm-pm-prompts.md](./06c-desktop-operations-crm-pm-prompts.md) | Site Inventory, CRM, PM |
| [06d-desktop-drawings-admin-prompts.md](./06d-desktop-drawings-admin-prompts.md) | Drawings, Petty Cash, Admin, Developer |
| [07-mobile-design-system-prompt.md](./07-mobile-design-system-prompt.md) | Mobile foundations |
| [08-mobile-application-shell-prompt.md](./08-mobile-application-shell-prompt.md) | Mobile nav shell |
| [09-mobile-module-prompts.md](./09-mobile-module-prompts.md) | Mobile module prompts |
| [10-responsive-design-prompt.md](./10-responsive-design-prompt.md) | Desktop/tablet/mobile coherence |
| [11-cross-screen-consistency-prompt.md](./11-cross-screen-consistency-prompt.md) | Alignment pass |
| [12-desktop-ux-audit-prompt.md](./12-desktop-ux-audit-prompt.md) | Desktop a11y/UX audit |
| [13-mobile-ux-audit-prompt.md](./13-mobile-ux-audit-prompt.md) | Mobile UX audit |
| [14-final-design-completeness-prompt.md](./14-final-design-completeness-prompt.md) | Coverage verification prompt |
| [15-stitch-generation-guide.md](./15-stitch-generation-guide.md) | Step-by-step Stitch usage |
| [16-figma-handoff-guide.md](./16-figma-handoff-guide.md) | Figma structure & transfer |
| [17-unresolved-design-decisions.md](./17-unresolved-design-decisions.md) | Open product questions |

## Desktop generation order (short)

Foundations → Shell → Auth → Overview/Projects → Steel/Optimizer → BBS/Casting → Site Inv/CRM/PM → Drawings/Admin → Consistency → Desktop audit.

## Mobile generation order (short)

Mobile foundations → Mobile shell → Auth/Home/Projects → Inventory → BBS/Casting → CRM/PM → Drawings/Petty → Responsive → Consistency → Mobile audit → Completeness.

## Maintaining visual consistency

- Always restate slate-emerald + Inter + project chip rules when Stitch drifts.
- Re-attach Foundations/Shell as references.
- Run prompt `11` after every large batch.
- Keep terminology aligned with nav labels in code (`Site Inventory`, `Projects & Tasks`, etc.).

## Reviewing generated screens

- Check against matrix IDs in `03`.
- Reject invented attendance/GPS time-tracking.
- Reject merged “Inventory” labeling that confuses steel vs site.
- Confirm blocks are project-scoped in every picker.

## Limitations & next steps

- Stitch context limits → modular prompts required.
- Figma auto-transfer not assumed — rebuild components manually.
- Mobile is design-only until a native/PWA project exists.
- Resolve items in `17` with product owners before locking IA.
- Optional next step: implement agreed designs in the Vite app (separate engineering task).

## Counts (audit snapshot)

| Metric | Approximate verified count |
|--------|----------------------------|
| Workspace + auth view IDs | **28** |
| Sidebar module destinations | **17** (+ Steel children) |
| Distinct desktop screens/tabs/modals inventoried | **90+** |
| Desktop prompt families | **14** (06.1–06.14) |
| Mobile prompt families | **6** (09.1–09.6) + shell/system |
| Backend Express module mounts | **8** routers + inline core APIs |
